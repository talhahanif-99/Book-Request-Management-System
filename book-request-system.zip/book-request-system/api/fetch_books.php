<?php
/**
 * api/fetch_books.php
 * Receives a category via FormData POST.
 * Checks rate limit, calls Google Books API, stores results, returns JSON.
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
session_start();

header('Content-Type: application/json');

// ── Must be a logged-in user ─────────────────────────────────────────────────
if (empty($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    echo json_encode(['error' => 'Unauthorized']); exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Invalid request method']); exit;
}

$userId   = (int)$_SESSION['user_id'];
$category = trim($_POST['category'] ?? '');

// ── Map category label → API query string ────────────────────────────────────
$queryMap = [
    'App Development'    => 'web+development',
    'Mobile Development' => 'mobile+development',
    'AI'                 => 'artificial+intelligence',
];

if (!array_key_exists($category, $queryMap)) {
    echo json_encode(['error' => 'Invalid category']); exit;
}

$rateLimited = false;

try {
    // ── Rate limit check: max 5 API calls in last 24 hours ───────────────────
    $rateStmt = $pdo->prepare(
        "SELECT COUNT(*) FROM api_call_log
         WHERE user_id = ? AND called_at >= NOW() - INTERVAL 24 HOUR"
    );
    $rateStmt->execute([$userId]);
    $callCount = (int)$rateStmt->fetchColumn();

    if ($callCount < API_CALLS_LIMIT) {
        // ── Call the Google Books API ─────────────────────────────────────────
        $query      = $queryMap[$category];
        $apiUrl     = "https://www.googleapis.com/books/v1/volumes?q={$query}&maxResults=20";
        $jsonString = @file_get_contents($apiUrl);

        if ($jsonString !== false) {
            $apiData = json_decode($jsonString, true);

            // ── Log this API call ──────────────────────────────────────────────
            $logStmt = $pdo->prepare('INSERT INTO api_call_log (user_id) VALUES (?)');
            $logStmt->execute([$userId]);

            // ── Insert books into DB (ignore duplicates) ───────────────────────
            $insStmt = $pdo->prepare(
                'INSERT IGNORE INTO books (title, author, category) VALUES (?, ?, ?)'
            );

            foreach ($apiData['items'] ?? [] as $item) {
                $info   = $item['volumeInfo'] ?? [];
                $title  = trim($info['title'] ?? '');
                $author = implode(', ', $info['authors'] ?? ['Unknown']);

                if ($title !== '') {
                    $insStmt->execute([$title, $author, $category]);
                }
            }
        }
        // If API call failed, we still fall through to serve cached books
    } else {
        $rateLimited = true;
    }

    // ── Fetch books for this category from the database ──────────────────────
    $bookStmt = $pdo->prepare(
        'SELECT title, author FROM books WHERE category = ? ORDER BY title ASC'
    );
    $bookStmt->execute([$category]);
    $books = $bookStmt->fetchAll();

    echo json_encode([
        'books'        => $books,
        'rate_limited' => $rateLimited,
    ]);

} catch (PDOException $e) {
    error_log('fetch_books error: ' . $e->getMessage());
    echo json_encode(['error' => 'Server error. Please try again.']);
}
