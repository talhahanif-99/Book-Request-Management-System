<?php
/**
 * user/cancel_request.php
 * POST handler – cancels a pending request belonging to the logged-in user.
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
session_start();
requireUserLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . BASE_URL . '/user/dashboard.php'); exit;
}

$requestId = (int)($_POST['request_id'] ?? 0);
$userId    = (int)$_SESSION['user_id'];

if ($requestId > 0) {
    try {
        // Only delete if it's the user's OWN request AND still pending
        $stmt = $pdo->prepare(
            "DELETE FROM book_requests
             WHERE id = ? AND user_id = ? AND status = 'pending'"
        );
        $stmt->execute([$requestId, $userId]);
    } catch (PDOException $e) {
        error_log('Cancel request error: ' . $e->getMessage());
    }
}

header('Location: ' . BASE_URL . '/user/dashboard.php');
exit;
