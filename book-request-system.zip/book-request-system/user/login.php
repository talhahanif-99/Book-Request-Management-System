<?php
/**
 * user/login.php
 * Authenticates a regular user.
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
session_start();

// Already logged in
if (!empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/user/dashboard.php'); exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['identifier'] ?? '');   // username or email
    $password   = $_POST['password'] ?? '';

    if (empty($identifier) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        try {
            // Look up by username OR email
            $stmt = $pdo->prepare(
                'SELECT * FROM users WHERE username=? OR email=? LIMIT 1'
            );
            $stmt->execute([$identifier, $identifier]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // Set session
                $_SESSION['user_id']  = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email']    = $user['email'];
                $_SESSION['role']     = 'user';
                header('Location: ' . BASE_URL . '/user/dashboard.php');
                exit;
            } else {
                $error = 'Invalid username/email or password.';
            }
        } catch (PDOException $e) {
            error_log('Login error: ' . $e->getMessage());
            $error = 'Login failed. Please try again.';
        }
    }
}

$pageTitle = 'User Login';
$navRole   = 'guest';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card p-4">
            <h4 class="mb-3 text-center"><i class="bi bi-person-circle me-2 text-primary"></i>User Login</h4>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= h($error) ?></div>
            <?php endif; ?>

            <form method="post" novalidate>
                <div class="mb-3">
                    <label class="form-label">Username or Email</label>
                    <input type="text" name="identifier" class="form-control"
                           value="<?= h($_POST['identifier'] ?? '') ?>" required autofocus>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Login</button>
            </form>

            <p class="mt-3 text-center small">
                No account? <a href="<?= BASE_URL ?>/user/register.php">Register here</a>
            </p>
            <hr>
            <p class="text-center small text-muted">
                Admin? <a href="<?= BASE_URL ?>/admin/login.php">Admin Login</a> &nbsp;|&nbsp;
                <a href="<?= BASE_URL ?>/superadmin/login.php">Super Admin Login</a>
            </p>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
