<?php
/**
 * user/dashboard.php
 * Shows the logged-in user's book requests and status notifications.
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
session_start();
requireUserLogin();

$userId = $_SESSION['user_id'];

try {
    // ── Fetch user's requests ─────────────────────────────────────────────────
    $stmt = $pdo->prepare(
        'SELECT * FROM book_requests WHERE user_id = ? ORDER BY updated_at DESC'
    );
    $stmt->execute([$userId]);
    $requests = $stmt->fetchAll();

    // ── Collect changed requests for notifications, then reset the flag ───────
    $notifications = array_filter($requests, fn($r) => $r['status_changed'] == 1);

    if (!empty($notifications)) {
        $ids = array_column(iterator_to_array((function() use ($notifications) {
            foreach ($notifications as $n) yield $n;
        })()), 'id');
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $upd = $pdo->prepare(
            "UPDATE book_requests SET status_changed = 0 WHERE id IN ($placeholders)"
        );
        $upd->execute($ids);
    }
} catch (PDOException $e) {
    error_log('Dashboard error: ' . $e->getMessage());
    $requests      = [];
    $notifications = [];
}

$pageTitle = 'My Dashboard';
$navRole   = 'user';
require_once __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-speedometer2 me-2"></i>My Dashboard</h4>

<?php foreach ($notifications as $n): ?>
    <div class="alert alert-info alert-dismissible fade show" role="alert">
        <i class="bi bi-bell-fill me-2"></i>
        Your request for <strong><?= h($n['book_title']) ?></strong> is now
        <strong><?= h(ucfirst(str_replace('_', ' ', $n['status']))) ?></strong>.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endforeach; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <span class="text-muted">Total requests: <?= count($requests) ?></span>
    <a href="<?= BASE_URL ?>/user/request_book.php" class="btn btn-primary btn-sm">
        <i class="bi bi-plus-lg"></i> New Request
    </a>
</div>

<?php if (empty($requests)): ?>
    <div class="card p-4 text-center text-muted">
        <i class="bi bi-inbox display-5 mb-2"></i>
        <p>No book requests yet. <a href="<?= BASE_URL ?>/user/request_book.php">Make one!</a></p>
    </div>
<?php else: ?>
    <div class="card">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Book Title</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Requested</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests as $i => $req): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><?= h($req['book_title']) ?></td>
                        <td><?= h($req['category']) ?></td>
                        <td>
                            <span class="badge bg-<?= statusBadge($req['status']) ?>">
                                <?= h(ucfirst(str_replace('_', ' ', $req['status']))) ?>
                            </span>
                        </td>
                        <td class="small text-muted"><?= h($req['created_at']) ?></td>
                        <td>
                            <?php if ($req['status'] === 'pending'): ?>
                                <form method="post" action="<?= BASE_URL ?>/user/cancel_request.php"
                                      onsubmit="return confirm('Cancel this request?')">
                                    <input type="hidden" name="request_id" value="<?= (int)$req['id'] ?>">
                                    <button class="btn btn-sm btn-outline-danger">
                                        <i class="bi bi-x-circle"></i> Cancel
                                    </button>
                                </form>
                            <?php else: ?>
                                <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
