<?php
/**
 * user/request_book.php
 * Lets user pick a category, which triggers a JS fetch to api/fetch_books.php.
 * Books populate a <select>; submitting inserts a row into book_requests.
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
session_start();
requireUserLogin();

$userId   = (int)$_SESSION['user_id'];
$username = $_SESSION['username'];
$email    = $_SESSION['email'];
$error    = '';
$success  = '';

$categories = [
    'App Development'    => 'web+development',
    'Mobile Development' => 'mobile+development',
    'AI'                 => 'artificial+intelligence',
];

// ── Handle form submission ────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_title'])) {
    $category  = trim($_POST['category']   ?? '');
    $bookTitle = trim($_POST['book_title'] ?? '');

    if (empty($category) || empty($bookTitle)) {
        $error = 'Please select a category and a book title.';
    } elseif (!array_key_exists($category, $categories)) {
        $error = 'Invalid category.';
    } else {
        try {
            $ins = $pdo->prepare(
                'INSERT INTO book_requests (user_id, username, email, category, book_title)
                 VALUES (?, ?, ?, ?, ?)'
            );
            $ins->execute([$userId, $username, $email, $category, $bookTitle]);
            $success = 'Your request has been submitted successfully!';
        } catch (PDOException $e) {
            error_log('Request insert error: ' . $e->getMessage());
            $error = 'Could not submit request. Please try again.';
        }
    }
}

$pageTitle = 'Request a Book';
$navRole   = 'user';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
<div class="col-md-7">
<div class="card p-4">
    <h4 class="mb-3"><i class="bi bi-journal-plus me-2 text-primary"></i>Request a Book</h4>

    <?php if ($error):   ?><div class="alert alert-danger"><?=  h($error)   ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= h($success) ?>
        <a href="<?= BASE_URL ?>/user/dashboard.php" class="alert-link ms-2">View My Requests →</a>
    </div><?php endif; ?>

    <form method="post" id="requestForm" novalidate>
        <!-- Username (read-only) -->
        <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" class="form-control" value="<?= h($username) ?>" readonly>
        </div>

        <!-- Email (read-only) -->
        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" value="<?= h($email) ?>" readonly>
        </div>

        <!-- Category -->
        <div class="mb-3">
            <label class="form-label">Category <span class="text-danger">*</span></label>
            <select name="category" id="categorySelect" class="form-select" required>
                <option value="">— Select a category —</option>
                <?php foreach ($categories as $label => $query): ?>
                    <option value="<?= h($label) ?>"
                        data-query="<?= h($query) ?>"
                        <?= (($_POST['category'] ?? '') === $label) ? 'selected' : '' ?>>
                        <?= h($label) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Book Title (populated via JS) -->
        <div class="mb-3">
            <label class="form-label">Book Title <span class="text-danger">*</span></label>
            <div id="booksLoading" class="text-muted small mb-1 d-none">
                <span class="spinner-border spinner-border-sm me-1"></span> Loading books…
            </div>
            <div id="apiLimitMsg" class="alert alert-warning d-none small py-2">
                <i class="bi bi-exclamation-triangle-fill me-1"></i>
                API rate limit reached (5/day). Previously fetched books are shown below.
            </div>
            <select name="book_title" id="bookSelect" class="form-select" required>
                <option value="">— Select a book —</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary w-100">
            <i class="bi bi-send-fill me-1"></i> Submit Request
        </button>
    </form>
</div>
</div>
</div>

<script>
const categorySelect = document.getElementById('categorySelect');
const bookSelect     = document.getElementById('bookSelect');
const loadingDiv     = document.getElementById('booksLoading');
const limitMsg       = document.getElementById('apiLimitMsg');
const baseUrl        = '<?= BASE_URL ?>';

categorySelect.addEventListener('change', async function () {
    const category = this.value;
    if (!category) {
        bookSelect.innerHTML = '<option value="">— Select a book —</option>';
        return;
    }

    // Show spinner, clear old options
    loadingDiv.classList.remove('d-none');
    limitMsg.classList.add('d-none');
    bookSelect.innerHTML = '<option value="">Loading…</option>';

    try {
        const formData = new FormData();
        formData.append('category', category);

        const res  = await fetch(baseUrl + '/api/fetch_books.php', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();

        loadingDiv.classList.add('d-none');

        if (data.rate_limited) {
            limitMsg.classList.remove('d-none');
        }

        if (data.error) {
            bookSelect.innerHTML = `<option value="">Error: ${data.error}</option>`;
            return;
        }

        bookSelect.innerHTML = '<option value="">— Select a book —</option>';
        (data.books || []).forEach(b => {
            const opt = document.createElement('option');
            opt.value       = b.title;
            opt.textContent = b.title + (b.author ? ` — ${b.author}` : '');
            bookSelect.appendChild(opt);
        });

        if ((data.books || []).length === 0) {
            bookSelect.innerHTML = '<option value="">No books found</option>';
        }
    } catch (err) {
        loadingDiv.classList.add('d-none');
        bookSelect.innerHTML = '<option value="">Failed to load books</option>';
    }
});

// Auto-trigger if category was pre-selected (e.g. after failed submit)
if (categorySelect.value) categorySelect.dispatchEvent(new Event('change'));
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
