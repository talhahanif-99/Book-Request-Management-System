# 📚 Book Request Management System

A multi-role PHP + MySQL web application for managing book requests with Google Books API integration.

---

## Features

| Role        | Capabilities                                                                  |
|-------------|-------------------------------------------------------------------------------|
| User        | Register/Login, browse books by category (via Google Books API), submit and cancel requests, view own dashboard with status notifications |
| Admin       | View-only statistics dashboard (unique users, total/pending/in-progress/completed requests) |
| Super Admin | Full CRUD on requests, user management (reset passwords, delete), admin management (add/delete) |

---

## Requirements

- PHP 7.4+
- MySQL 5.7+ / MariaDB 10.3+
- XAMPP / WAMP / LAMP
- Internet connection (for Google Books API)

---

## Installation

### 1. Clone / Extract

Place the project folder in your XAMPP `htdocs` directory:

```
C:\xampp\htdocs\book-request-system\
```

### 2. Import the Database

1. Open **phpMyAdmin** → `http://localhost/phpmyadmin`
2. Click **New** and create a database named `book_request_system` (or just import — the SQL creates it automatically)
3. Select the database → click **Import**
4. Choose `database.sql` from the project root → click **Go**

### 3. Configure the Database Connection

Open `config/db.php` and update credentials if needed:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'book_request_system');
define('DB_USER', 'root');   // your MySQL username
define('DB_PASS', '');       // your MySQL password (empty by default in XAMPP)
```

### 4. Set the Base URL

In `config/db.php`, update `BASE_URL` to match your project folder:

```php
define('BASE_URL', '/book-request-system');
// Use '' if placed directly in htdocs root
```

### 5. Generate Correct Password Hashes (Important!)

Visit the setup script in your browser **once**:

```
http://localhost/book-request-system/setup.php
```

This re-generates correct `password_hash()` values for the default accounts and saves them to the database.

**⚠️ Delete `setup.php` immediately after running it.**

### 6. Start the Application

Visit: `http://localhost/book-request-system/`

---

## Default Credentials

| Role        | Username     | Password    | Login URL                              |
|-------------|--------------|-------------|----------------------------------------|
| Super Admin | `superadmin` | `Admin@1234`| `/superadmin/login.php`                |
| Admin       | `admin1`     | `Admin@1234`| `/admin/login.php`                     |
| User        | *(register)* | *(your own)*| `/user/register.php`                   |

> **Change these passwords immediately after first login!**

---

## Project Structure

```
book-request-system/
├── config/
│   └── db.php                  ← PDO connection + constants
├── includes/
│   ├── auth.php                ← Session guards + helper functions
│   ├── header.php              ← Common HTML header (Bootstrap 5)
│   └── footer.php              ← Common footer + JS
├── user/
│   ├── register.php            ← User registration
│   ├── login.php               ← User login
│   ├── dashboard.php           ← User's request dashboard + notifications
│   ├── request_book.php        ← Book request form (API-powered)
│   └── cancel_request.php      ← Cancel pending request (POST handler)
├── admin/
│   ├── login.php               ← Admin login
│   └── dashboard.php           ← Stats overview
├── superadmin/
│   ├── login.php               ← Super admin login
│   ├── dashboard.php           ← Overview + quick links
│   ├── manage_requests.php     ← Edit status / delete requests
│   ├── manage_users.php        ← Reset passwords / delete users
│   └── manage_admins.php       ← Add / delete admins
├── api/
│   └── fetch_books.php         ← Google Books API handler (rate-limited)
├── index.php                   ← Entry point (redirects by session)
├── logout.php                  ← Destroys session
├── setup.php                   ← One-time admin setup (DELETE AFTER USE)
├── database.sql                ← Full schema + seed data
└── README.md
```

---

## Security Measures

- Passwords stored using `password_hash()` (bcrypt), verified with `password_verify()`
- All queries use **PDO prepared statements** — no raw SQL concatenation
- All user input sanitized with `htmlspecialchars()` before display
- Role checks on every protected page (`requireUserLogin()`, `requireAdminLogin()`, `requireSuperAdminLogin()`)
- Sessions are completely destroyed on logout
- API rate limit: 5 calls per user per 24 hours

---

## Testing Tips

- Use **different browsers or incognito tabs** to test multiple roles simultaneously
- Use **phpMyAdmin** to inspect `book_requests`, `api_call_log`, and `books` tables in real time
- Temporarily set `ini_set('display_errors', 1)` in `config/db.php` during development, reset to `0` before submission

---

## Submission Format

Zip the folder and rename it: `yourname_rollnumber.zip`  
Example: `ali_ahmed_2201234.zip`
