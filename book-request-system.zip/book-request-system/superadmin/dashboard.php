<?php
/**
 * superadmin/dashboard.php
 * Overview statistics for the super admin.
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
session_start();
requireSuperAdminLogin();

try {
    $totalUsers    = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    $totalAdmins   = (int)$pdo->query("SELECT COUNT(*) FROM admins WHERE role='admin'")->fetchColumn();
    $totalRequests = (int)$pdo->query('SELECT COUNT(*) FROM book_requests')->fetchColumn();
    $pending       = (int)$pdo->query("SELECT COUNT(*) FROM book_requests WHERE status='pending'")->fetchColumn();
    $inProgress    = (int)$pdo->query("SELECT COUNT(*) FROM book_requests WHERE status='in_progress'")->fetchColumn();
    $completed     = (int)$pdo->query("SELECT COUNT(*) FROM book_requests WHERE status='completed'")->fetchColumn();
    $totalBooks    = (int)$pdo->query('SELECT COUNT(*) FROM books')->fetchColumn();

    $recent = $pdo->query(
        'SELECT br.*, u.email FROM book_requests br
         LEFT JOIN users u ON u.id = br.user_id
         ORDER BY br.updated_at DESC LIMIT 8'
    )->fetchAll();
} catch (PDOException $e) {
    error_log('SA dashboard: ' . $e->getMessage());
    $totalUsers = $totalAdmins = $totalRequests = $pending = $inProgress = $completed = $totalBooks = 0;
    $recent = [];
}

$pageTitle = 'Super Admin Dashboard';
$navRole   = 'superadmin';
require_once __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-4"><i class="bi bi-shield-check me-2 text-danger"></i>Super Admin Dashboard</h4>

<!-- ── Stats ─────────────────────────────────────────────────────────────── -->
<div class="row g-3 mb-4">
<?php
$cards = [
    ['Registered Users',    $totalUsers,    'people-fill',      'primary'],
    ['Admin Accounts',      $totalAdmins,   'person-badge',     'warning'],
    ['Total Books (DB)',    $totalBooks,    'journals',         'secondary'],
    ['Total Requests',      $totalRequests, 'journal-bookmark', 'dark'],
    ['Pending',             $pending,       'hourglass-split',  'warning'],
    ['In Progress',         $inProgress,    'arrow-repeat',     'info'],
    ['Completed',           $completed,     'check-circle-fill','success'],
];
foreach ($cards as [$label, $value, $icon, $color]):
?>
    <div class="col-6 col-sm-4 col-md-3 col-lg-auto flex-grow-1">
        <div class="card stat-card text-center p-3 h-100">
            <i class="bi bi-<?= $icon ?> fs-2 text-<?= $color ?>"></i>
            <div class="display-6 mt-1"><?= $value ?></div>
            <div class="small text-muted"><?= $label ?></div>
        </div>
    </div>
<?php endforeach; ?>
</div>

<!-- ── Quick links ────────────────────────────────────────────────────────── -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <a href="<?= BASE_URL ?>/superadmin/manage_requests.php"
           class="btn btn-outline-primary w-100 py-3">
            <i class="bi bi-journal-check fs-4 d-block mb-1"></i> Manage Requests
        </a>
    </div>
    <div class="col-md-4">
        <a href="<?= BASE_URL ?>/superadmin/manage_users.php"
           class="btn btn-outline-warning w-100 py-3">
            <i class="bi bi-people fs-4 d-block mb-1"></i> Manage Users
        </a>
    </div>
    <div class="col-md-4">
        <a href="<?= BASE_URL ?>/superadmin/manage_admins.php"
           class="btn btn-outline-danger w-100 py-3">
            <i class="bi bi-person-badge fs-4 d-block mb-1"></i> Manage Admins
        </a>
    </div>
</div>

<!-- ── Recent activity ───────────────────────────────────────────────────── -->
<div class="card">
    <div class="card-header fw-semibold">Recent Activity</div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr><th>User</th><th>Book</th><th>Category</th><th>Status</th><th>Updated</th></tr>
            </thead>
            <tbody>
            <?php foreach ($recent as $r): ?>
                <tr>
                    <td><?= h($r['username']) ?></td>
                    <td><?= h($r['book_title']) ?></td>
                    <td><?= h($r['category']) ?></td>
                    <td>
                        <span class="badge bg-<?= statusBadge($r['status']) ?>">
                            <?= ucfirst(str_replace('_',' ',$r['status'])) ?>
                        </span>
                    </td>
                    <td class="small text-muted"><?= h($r['updated_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
