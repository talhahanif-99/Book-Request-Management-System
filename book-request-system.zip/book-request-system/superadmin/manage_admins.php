<?php
/**
 * superadmin/manage_admins.php
 * Add new admins and delete existing ones (superadmin account is protected).
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
session_start();
requireSuperAdminLogin();

$message = '';
$msgType = 'success';

// ── POST handler ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'add_admin') {
            $newUser = trim($_POST['new_username'] ?? '');
            $newPass = $_POST['new_password'] ?? '';

            if (empty($newUser) || empty($newPass)) {
                $message = 'Username and password are required.'; $msgType = 'danger';
            } elseif (strlen($newPass) < 6) {
                $message = 'Password must be at least 6 characters.'; $msgType = 'danger';
            } else {
                // Check duplicate
                $chk = $pdo->prepare('SELECT id FROM admins WHERE username = ?');
                $chk->execute([$newUser]);
                if ($chk->fetch()) {
                    $message = "Username '$newUser' is already taken."; $msgType = 'danger';
                } else {
                    $hash = password_hash($newPass, PASSWORD_DEFAULT);
                    $pdo->prepare("INSERT INTO admins (username, password, role) VALUES (?, ?, 'admin')")
                        ->execute([$newUser, $hash]);
                    $message = "Admin <strong>" . h($newUser) . "</strong> added successfully.";
                }
            }

        } elseif ($action === 'delete_admin') {
            $adminId = (int)($_POST['admin_id'] ?? 0);

            // Fetch the target admin to verify it's not a superadmin
            $chk = $pdo->prepare('SELECT username, role FROM admins WHERE id = ?');
            $chk->execute([$adminId]);
            $target = $chk->fetch();

            if (!$target) {
                $message = 'Admin not found.'; $msgType = 'danger';
            } elseif ($target['role'] === 'superadmin') {
                $message = 'Super Admin accounts cannot be deleted.'; $msgType = 'danger';
            } else {
                $pdo->prepare('DELETE FROM admins WHERE id = ?')->execute([$adminId]);
                $message = "Admin <strong>" . h($target['username']) . "</strong> deleted.";
            }
        }
    } catch (PDOException $e) {
        error_log('Manage admins error: ' . $e->getMessage());
        $message = 'Operation failed. Please try again.'; $msgType = 'danger';
    }
}

// ── Fetch all admins (excluding superadmin from the list, shown separately) ───
try {
    $admins = $pdo->query(
        "SELECT * FROM admins WHERE role = 'admin' ORDER BY created_at DESC"
    )->fetchAll();
} catch (PDOException $e) {
    error_log('Fetch admins error: ' . $e->getMessage());
    $admins = [];
}

$pageTitle = 'Manage Admins';
$navRole   = 'superadmin';
require_once __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-4"><i class="bi bi-person-badge-fill me-2 text-danger"></i>Manage Admins</h4>

<?php if ($message): ?>
    <div class="alert alert-<?= $msgType ?> alert-dismissible fade show">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- ── Add admin form ──────────────────────────────────────────────────── -->
    <div class="col-md-4">
        <div class="card p-3">
            <h6 class="mb-3"><i class="bi bi-person-plus-fill me-2 text-success"></i>Add New Admin</h6>
            <form method="post" novalidate>
                <input type="hidden" name="action" value="add_admin">
                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" name="new_username" class="form-control"
                           placeholder="admin_username" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="new_password" class="form-control"
                           placeholder="Min 6 characters" required>
                </div>
                <button type="submit" class="btn btn-success w-100">
                    <i class="bi bi-person-plus-fill me-1"></i> Add Admin
                </button>
            </form>
        </div>
    </div>

    <!-- ── Admin list ─────────────────────────────────────────────────────── -->
    <div class="col-md-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span class="fw-semibold">Admin Accounts</span>
                <span class="badge bg-secondary"><?= count($admins) ?></span>
            </div>
            <?php if (empty($admins)): ?>
                <div class="card-body text-center text-muted">No admin accounts yet.</div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr><th>#</th><th>Username</th><th>Role</th><th>Created</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($admins as $i => $a): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><?= h($a['username']) ?></td>
                            <td><span class="badge bg-warning text-dark">Admin</span></td>
                            <td class="small text-muted"><?= h($a['created_at']) ?></td>
                            <td>
                                <form method="post"
                                      onsubmit="return confirm('Delete admin <?= h(addslashes($a['username'])) ?>?')">
                                    <input type="hidden" name="action"   value="delete_admin">
                                    <input type="hidden" name="admin_id" value="<?= (int)$a['id'] ?>">
                                    <button class="btn btn-sm btn-outline-danger">
                                        <i class="bi bi-trash3"></i> Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>

        <!-- Super admin notice -->
        <div class="alert alert-secondary mt-3 small">
            <i class="bi bi-shield-lock-fill me-1"></i>
            The <strong>Super Admin</strong> account is protected and cannot be deleted.
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
