<?php
/**
 * superadmin/manage_requests.php
 * View all requests, edit their status (Pending→In Progress→Completed), or delete.
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
session_start();
requireSuperAdminLogin();

$message = '';
$msgType = 'success';

// ── Handle POST actions (update status / delete) ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action    = $_POST['action']     ?? '';
    $requestId = (int)($_POST['request_id'] ?? 0);

    if ($requestId <= 0) {
        $message = 'Invalid request.'; $msgType = 'danger';
    } else {
        try {
            if ($action === 'update_status') {
                $newStatus = $_POST['status'] ?? '';
                $allowed   = ['pending', 'in_progress', 'completed'];
                if (!in_array($newStatus, $allowed, true)) {
                    $message = 'Invalid status.'; $msgType = 'danger';
                } else {
                    // Set status_changed = 1 so user gets notified
                    $stmt = $pdo->prepare(
                        'UPDATE book_requests
                         SET status = ?, status_changed = 1
                         WHERE id = ?'
                    );
                    $stmt->execute([$newStatus, $requestId]);
                    $message = 'Status updated successfully.';
                }
            } elseif ($action === 'delete') {
                $pdo->prepare('DELETE FROM book_requests WHERE id = ?')
                    ->execute([$requestId]);
                $message = 'Request deleted.';
            }
        } catch (PDOException $e) {
            error_log('Manage requests error: ' . $e->getMessage());
            $message = 'Operation failed. Please try again.'; $msgType = 'danger';
        }
    }
}

// ── Fetch all requests ────────────────────────────────────────────────────────
try {
    $requests = $pdo->query(
        'SELECT * FROM book_requests ORDER BY updated_at DESC'
    )->fetchAll();
} catch (PDOException $e) {
    error_log('Fetch requests error: ' . $e->getMessage());
    $requests = [];
}

$pageTitle = 'Manage Requests';
$navRole   = 'superadmin';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-journal-check me-2 text-primary"></i>Manage Book Requests</h4>
    <span class="badge bg-secondary fs-6"><?= count($requests) ?> total</span>
</div>

<?php if ($message): ?>
    <div class="alert alert-<?= $msgType ?> alert-dismissible fade show">
        <?= h($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if (empty($requests)): ?>
    <div class="card p-4 text-center text-muted"><i class="bi bi-inbox display-5"></i><p class="mt-2">No requests found.</p></div>
<?php else: ?>
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>#</th><th>User</th><th>Email</th><th>Book Title</th>
                    <th>Category</th><th>Status</th><th>Date</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($requests as $i => $req): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= h($req['username']) ?></td>
                    <td class="small"><?= h($req['email']) ?></td>
                    <td><?= h($req['book_title']) ?></td>
                    <td><?= h($req['category']) ?></td>
                    <td>
                        <!-- Inline status update form -->
                        <form method="post" class="d-flex gap-1 align-items-center">
                            <input type="hidden" name="action"     value="update_status">
                            <input type="hidden" name="request_id" value="<?= (int)$req['id'] ?>">
                            <select name="status" class="form-select form-select-sm" style="width:130px">
                                <?php foreach (['pending','in_progress','completed'] as $s): ?>
                                    <option value="<?= $s ?>" <?= $req['status']===$s?'selected':'' ?>>
                                        <?= ucfirst(str_replace('_',' ',$s)) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button class="btn btn-sm btn-outline-primary" title="Save">
                                <i class="bi bi-check-lg"></i>
                            </button>
                        </form>
                    </td>
                    <td class="small text-muted"><?= h($req['created_at']) ?></td>
                    <td>
                        <form method="post"
                              onsubmit="return confirm('Delete this request permanently?')">
                            <input type="hidden" name="action"     value="delete">
                            <input type="hidden" name="request_id" value="<?= (int)$req['id'] ?>">
                            <button class="btn btn-sm btn-outline-danger">
                                <i class="bi bi-trash3"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
