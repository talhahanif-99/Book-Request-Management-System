<?php
/**
 * superadmin/manage_users.php
 * View all users, reset their passwords, or delete their accounts.
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
session_start();
requireSuperAdminLogin();

$message   = '';
$msgType   = 'success';
$resetInfo = null; // Will hold ['username' => ..., 'password' => ...] after reset

// ── POST handler ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $uid    = (int)($_POST['user_id'] ?? 0);

    if ($uid <= 0) {
        $message = 'Invalid user.'; $msgType = 'danger';
    } else {
        try {
            if ($action === 'reset_password') {
                // Generate a random 10-char password
                $newPass   = substr(str_shuffle('ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789'), 0, 10);
                $newHash   = password_hash($newPass, PASSWORD_DEFAULT);
                $nameStmt  = $pdo->prepare('SELECT username FROM users WHERE id = ?');
                $nameStmt->execute([$uid]);
                $uname     = $nameStmt->fetchColumn();

                $pdo->prepare('UPDATE users SET password = ? WHERE id = ?')
                    ->execute([$newHash, $uid]);

                $resetInfo = ['username' => $uname, 'password' => $newPass];
                $message   = "Password reset for <strong>" . h($uname) . "</strong>.";

            } elseif ($action === 'delete_user') {
                // Fetch username for confirmation message
                $nameStmt = $pdo->prepare('SELECT username FROM users WHERE id = ?');
                $nameStmt->execute([$uid]);
                $uname = $nameStmt->fetchColumn();

                $pdo->prepare('DELETE FROM users WHERE id = ?')->execute([$uid]);
                $message = "User <strong>" . h($uname) . "</strong> has been deleted.";
            }
        } catch (PDOException $e) {
            error_log('Manage users error: ' . $e->getMessage());
            $message = 'Operation failed. Please try again.'; $msgType = 'danger';
        }
    }
}

// ── Fetch all users with request count ───────────────────────────────────────
try {
    $users = $pdo->query(
        'SELECT u.*, COUNT(r.id) AS req_count
         FROM users u
         LEFT JOIN book_requests r ON r.user_id = u.id
         GROUP BY u.id ORDER BY u.created_at DESC'
    )->fetchAll();
} catch (PDOException $e) {
    error_log('Fetch users error: ' . $e->getMessage());
    $users = [];
}

$pageTitle = 'Manage Users';
$navRole   = 'superadmin';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-people-fill me-2 text-warning"></i>Manage Users</h4>
    <span class="badge bg-secondary fs-6"><?= count($users) ?> users</span>
</div>

<?php if ($message): ?>
    <div class="alert alert-<?= $msgType ?> alert-dismissible fade show">
        <?= $message ?>
        <?php if ($resetInfo): ?>
            <br><strong>New password:</strong>
            <code id="newPassCode"><?= h($resetInfo['password']) ?></code>
            <button type="button" class="btn btn-sm btn-outline-secondary ms-2"
                    onclick="navigator.clipboard.writeText('<?= h($resetInfo['password']) ?>')">
                <i class="bi bi-clipboard"></i> Copy
            </button>
            <small class="d-block mt-1 text-danger">Share this with the user and ask them to change it.</small>
        <?php endif; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if (empty($users)): ?>
    <div class="card p-4 text-center text-muted">No registered users yet.</div>
<?php else: ?>
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr><th>#</th><th>Username</th><th>Email</th><th>Requests</th><th>Joined</th><th>Actions</th></tr>
            </thead>
            <tbody>
            <?php foreach ($users as $i => $u): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= h($u['username']) ?></td>
                    <td class="small"><?= h($u['email']) ?></td>
                    <td><span class="badge bg-secondary"><?= (int)$u['req_count'] ?></span></td>
                    <td class="small text-muted"><?= h($u['created_at']) ?></td>
                    <td>
                        <div class="d-flex gap-2">
                            <!-- Reset password -->
                            <form method="post"
                                  onsubmit="return confirm('Reset password for <?= h(addslashes($u['username'])) ?>?')">
                                <input type="hidden" name="action"  value="reset_password">
                                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                                <button class="btn btn-sm btn-outline-warning" title="Reset Password">
                                    <i class="bi bi-key-fill"></i>
                                </button>
                            </form>
                            <!-- Delete user -->
                            <form method="post"
                                  onsubmit="return confirm('Delete user <?= h(addslashes($u['username'])) ?> and ALL their requests? This cannot be undone.')">
                                <input type="hidden" name="action"  value="delete_user">
                                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                                <button class="btn btn-sm btn-outline-danger" title="Delete User">
                                    <i class="bi bi-person-x-fill"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
