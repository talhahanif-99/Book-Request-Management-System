<?php
/**
 * logout.php – Destroys the current session completely.
 */
require_once __DIR__ . '/config/db.php';
session_start();
session_unset();
session_destroy();
header('Location: ' . BASE_URL . '/user/login.php');
exit;
