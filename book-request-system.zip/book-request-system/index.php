<?php
/**
 * index.php – Entry point; redirects to user login.
 */
require_once __DIR__ . '/config/db.php';
session_start();

// If already logged in, go straight to the right panel
if (!empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/user/dashboard.php');
} elseif (!empty($_SESSION['admin_id'])) {
    $dest = ($_SESSION['role'] === 'superadmin') ? '/superadmin/dashboard.php' : '/admin/dashboard.php';
    header('Location: ' . BASE_URL . $dest);
} else {
    header('Location: ' . BASE_URL . '/user/login.php');
}
exit;
