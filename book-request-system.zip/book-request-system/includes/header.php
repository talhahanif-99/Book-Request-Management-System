<?php
/**
 * includes/header.php
 * Variables expected before include:
 *   $pageTitle  (string) – browser tab title
 *   $navRole    (string) – 'user' | 'admin' | 'superadmin' | 'guest'
 */
$pageTitle = $pageTitle ?? 'Book Request System';
$navRole   = $navRole   ?? 'guest';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= h($pageTitle) ?> – BookReq</title>
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { background: #f0f4f8; }
        .navbar-brand { font-weight: 700; letter-spacing: .5px; }
        .card { border: none; box-shadow: 0 2px 12px rgba(0,0,0,.08); }
        .stat-card .display-6 { font-weight: 700; }
        .table th { background: #f8f9fa; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="<?= BASE_URL ?>/">
            <i class="bi bi-book-half me-2"></i>BookReq
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto">
                <?php if ($navRole === 'user'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>/user/dashboard.php">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>/user/request_book.php">
                            <i class="bi bi-plus-circle"></i> Request Book
                        </a>
                    </li>
                    <li class="nav-item">
                        <span class="nav-link text-warning">
                            <i class="bi bi-person-fill"></i>
                            <?= h($_SESSION['username'] ?? '') ?>
                        </span>
                    </li>
                <?php elseif ($navRole === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>/admin/dashboard.php">
                            <i class="bi bi-bar-chart"></i> Dashboard
                        </a>
                    </li>
                <?php elseif ($navRole === 'superadmin'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>/superadmin/dashboard.php">
                            <i class="bi bi-shield-check"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>/superadmin/manage_requests.php">
                            Requests
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>/superadmin/manage_users.php">
                            Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>/superadmin/manage_admins.php">
                            Admins
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ($navRole !== 'guest'): ?>
                    <li class="nav-item">
                        <a class="nav-link text-warning" href="<?= BASE_URL ?>/logout.php">
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<div class="container pb-5">
