<?php
/**
 * includes/footer.php
 * Closes the .container div opened in header.php and loads Bootstrap JS.
 */
?>
</div><!-- /.container -->

<footer class="text-center text-muted py-3 mt-4 border-top small">
    &copy; <?= date('Y') ?> BookReq &mdash; Book Request Management System
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
