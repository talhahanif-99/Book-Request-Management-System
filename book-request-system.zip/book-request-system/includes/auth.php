<?php
/**
 * includes/auth.php
 * Session guard helpers.  Include AFTER session_start().
 */

/** Redirect user to login if not authenticated as 'user'. */
function requireUserLogin(): void {
    if (empty($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'user') {
        header('Location: ' . BASE_URL . '/user/login.php');
        exit;
    }
}

/** Redirect to admin login if not authenticated as 'admin'. */
function requireAdminLogin(): void {
    if (empty($_SESSION['admin_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
        header('Location: ' . BASE_URL . '/admin/login.php');
        exit;
    }
}

/** Redirect to superadmin login if not authenticated as 'superadmin'. */
function requireSuperAdminLogin(): void {
    if (empty($_SESSION['admin_id']) || ($_SESSION['role'] ?? '') !== 'superadmin') {
        header('Location: ' . BASE_URL . '/superadmin/login.php');
        exit;
    }
}

/** Sanitize a string for safe HTML output. */
function h(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/** Return a Bootstrap badge class for a request status. */
function statusBadge(string $status): string {
    return match($status) {
        'pending'     => 'warning text-dark',
        'in_progress' => 'info text-dark',
        'completed'   => 'success',
        default       => 'secondary',
    };
}
