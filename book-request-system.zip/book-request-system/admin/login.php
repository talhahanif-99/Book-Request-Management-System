<?php
/**
 * admin/login.php
 * Authenticates an admin (role = 'admin').
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
session_start();

// Redirect if already logged in as admin
if (!empty($_SESSION['admin_id']) && $_SESSION['role'] === 'admin') {
    header('Location: ' . BASE_URL . '/admin/dashboard.php'); exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password']      ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        try {
            $stmt = $pdo->prepare(
                "SELECT * FROM admins WHERE username = ? AND role = 'admin' LIMIT 1"
            );
            $stmt->execute([$username]);
            $admin = $stmt->fetch();

            if ($admin && password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['username'] = $admin['username'];
                $_SESSION['role']     = 'admin';
                header('Location: ' . BASE_URL . '/admin/dashboard.php');
                exit;
            } else {
                $error = 'Invalid admin credentials.';
            }
        } catch (PDOException $e) {
            error_log('Admin login error: ' . $e->getMessage());
            $error = 'Login failed. Please try again.';
        }
    }
}

$pageTitle = 'Admin Login';
$navRole   = 'guest';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card p-4 border-top border-warning border-4">
            <h4 class="mb-3 text-center">
                <i class="bi bi-person-badge-fill me-2 text-warning"></i>Admin Login
            </h4>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= h($error) ?></div>
            <?php endif; ?>

            <form method="post" novalidate>
                <div class="mb-3">
                    <label class="form-label">Admin Username</label>
                    <input type="text" name="username" class="form-control"
                           value="<?= h($_POST['username'] ?? '') ?>" required autofocus>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-warning w-100 fw-bold">Login as Admin</button>
            </form>
            <p class="mt-3 text-center small">
                <a href="<?= BASE_URL ?>/user/login.php">← User Login</a>
                &nbsp;|&nbsp;
                <a href="<?= BASE_URL ?>/superadmin/login.php">Super Admin Login</a>
            </p>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
