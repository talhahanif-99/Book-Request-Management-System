<?php
/**
 * admin/dashboard.php
 * Read-only statistics dashboard for the admin role.
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
session_start();
requireAdminLogin();

try {
    // ── Aggregate stats using the required SQL ────────────────────────────────
    $stats = [];

    // Total unique users who have made at least one request
    $stats['unique_users'] = (int)$pdo
        ->query('SELECT COUNT(DISTINCT user_id) FROM book_requests')
        ->fetchColumn();

    // Total book requests
    $stats['total_requests'] = (int)$pdo
        ->query('SELECT COUNT(*) FROM book_requests')
        ->fetchColumn();

    // In-progress requests
    $stats['in_progress'] = (int)$pdo
        ->query("SELECT COUNT(*) FROM book_requests WHERE status='in_progress'")
        ->fetchColumn();

    // Completed requests
    $stats['completed'] = (int)$pdo
        ->query("SELECT COUNT(*) FROM book_requests WHERE status='completed'")
        ->fetchColumn();

    // Pending requests (bonus stat)
    $stats['pending'] = (int)$pdo
        ->query("SELECT COUNT(*) FROM book_requests WHERE status='pending'")
        ->fetchColumn();

    // Recent 10 requests for a quick overview
    $recent = $pdo
        ->query('SELECT * FROM book_requests ORDER BY created_at DESC LIMIT 10')
        ->fetchAll();

} catch (PDOException $e) {
    error_log('Admin dashboard error: ' . $e->getMessage());
    $stats  = array_fill_keys(['unique_users','total_requests','in_progress','completed','pending'], 0);
    $recent = [];
}

$pageTitle = 'Admin Dashboard';
$navRole   = 'admin';
require_once __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-4"><i class="bi bi-bar-chart-line-fill me-2 text-warning"></i>Admin Dashboard</h4>

<!-- ── Stat cards ─────────────────────────────────────────────────────────── -->
<div class="row g-3 mb-4">
    <?php
    $cards = [
        ['Total Unique Users',    $stats['unique_users'],    'people-fill',      'primary'],
        ['Total Book Requests',   $stats['total_requests'],  'journal-bookmark', 'secondary'],
        ['Requests In Progress',  $stats['in_progress'],     'arrow-repeat',     'info'],
        ['Completed Requests',    $stats['completed'],       'check-circle-fill','success'],
        ['Pending Requests',      $stats['pending'],         'hourglass-split',  'warning'],
    ];
    foreach ($cards as [$label, $value, $icon, $color]):
    ?>
    <div class="col-6 col-md-4 col-lg-2-4">
        <div class="card stat-card h-100 text-center p-3">
            <i class="bi bi-<?= $icon ?> fs-2 text-<?= $color ?>"></i>
            <div class="display-6 mt-2"><?= $value ?></div>
            <div class="small text-muted"><?= $label ?></div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- ── Recent requests table ─────────────────────────────────────────────── -->
<div class="card">
    <div class="card-header fw-semibold">Recent Requests (last 10)</div>
    <?php if (empty($recent)): ?>
        <div class="card-body text-center text-muted">No requests yet.</div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>User</th><th>Email</th><th>Book Title</th>
                    <th>Category</th><th>Status</th><th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent as $r): ?>
                <tr>
                    <td><?= h($r['username']) ?></td>
                    <td class="small"><?= h($r['email']) ?></td>
                    <td><?= h($r['book_title']) ?></td>
                    <td><?= h($r['category']) ?></td>
                    <td>
                        <span class="badge bg-<?= statusBadge($r['status']) ?>">
                            <?= h(ucfirst(str_replace('_', ' ', $r['status']))) ?>
                        </span>
                    </td>
                    <td class="small text-muted"><?= h($r['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<style>
.col-lg-2-4 { flex: 0 0 auto; width: 20%; }
@media(max-width:991px){ .col-lg-2-4{width:33.33%;} }
@media(max-width:575px){ .col-lg-2-4{width:50%;} }
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
