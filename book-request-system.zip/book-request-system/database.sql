-- ============================================================
-- Book Request Management System - Database Schema
-- Import this file into phpMyAdmin before running the project
-- ============================================================

CREATE DATABASE IF NOT EXISTS book_request_system
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE book_request_system;

-- --------------------------------------------------------
-- Table: users
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email    VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- --------------------------------------------------------
-- Table: admins  (stores both admin and superadmin)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS admins (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role     ENUM('admin','superadmin') NOT NULL DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- --------------------------------------------------------
-- Table: books  (populated via Google Books API)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS books (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    title    VARCHAR(255) NOT NULL,
    author   VARCHAR(255) DEFAULT 'Unknown',
    category VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_book_category (title(200), category)
) ENGINE=InnoDB;

-- --------------------------------------------------------
-- Table: book_requests
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS book_requests (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT NOT NULL,
    username   VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL,
    category   VARCHAR(100) NOT NULL,
    book_title VARCHAR(255) NOT NULL,
    status     ENUM('pending','in_progress','completed') NOT NULL DEFAULT 'pending',
    status_changed TINYINT(1) NOT NULL DEFAULT 0,   -- 1 = user has unseen status update
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- --------------------------------------------------------
-- Table: api_call_log  (rate-limit: max 5 calls / 24 h)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS api_call_log (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    user_id   INT NOT NULL,
    called_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- --------------------------------------------------------
-- Default Super Admin
-- Username : superadmin
-- Password : Admin@1234
-- (hash generated with password_hash('Admin@1234', PASSWORD_DEFAULT))
-- --------------------------------------------------------
INSERT IGNORE INTO admins (username, password, role)
VALUES (
    'superadmin',
    '$2y$12$GKGM3zOHGQLj8g1W5LqiXuGGGJC8xXQT2yxuYLSlH5ZRXGYnM4O2.',
    'superadmin'
);

-- --------------------------------------------------------
-- Sample Admin account
-- Username : admin1
-- Password : Admin@1234
-- --------------------------------------------------------
INSERT IGNORE INTO admins (username, password, role)
VALUES (
    'admin1',
    '$2y$12$GKGM3zOHGQLj8g1W5LqiXuGGGJC8xXQT2yxuYLSlH5ZRXGYnM4O2.',
    'admin'
);
