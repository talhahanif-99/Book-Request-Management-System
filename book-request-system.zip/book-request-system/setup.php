<?php
/**
 * setup.php  –  Run ONCE to insert / reset the super-admin account.
 * Visit http://localhost/book-request-system/setup.php in your browser,
 * then DELETE this file immediately afterwards.
 */

$dsn = 'mysql:host=localhost;dbname=book_request_system;charset=utf8mb4';
try {
    $pdo = new PDO($dsn, 'root', '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    die('DB Error: ' . $e->getMessage());
}

$users = [
    ['superadmin', 'Admin@1234', 'superadmin'],
    ['admin1',     'Admin@1234', 'admin'],
];

foreach ($users as [$uname, $plain, $role]) {
    $hash = password_hash($plain, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare(
        "INSERT INTO admins (username, password, role)
         VALUES (:u, :p, :r)
         ON DUPLICATE KEY UPDATE password = :p2, role = :r2"
    );
    $stmt->execute([':u' => $uname, ':p' => $hash, ':r' => $role, ':p2' => $hash, ':r2' => $role]);
    echo "<p>✔ <strong>$uname</strong> ($role) created/updated — password: <code>$plain</code></p>";
}
echo "<hr><p style='color:red'><strong>Delete this file now!</strong></p>";
