<?php
/**
 * config/db.php
 * Central PDO connection + global constants.
 * Required by every page via: require_once __DIR__ . '/../config/db.php';
 */

error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ── Project base URL (no trailing slash) ────────────────────────────────────
// Change to '' if placed directly in htdocs root.
define('BASE_URL', '/book-request-system');

// ── Database credentials ─────────────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_NAME', 'book_request_system');
define('DB_USER', 'root');
define('DB_PASS', '');

// ── Google Books API rate limit ───────────────────────────────────────────────
define('API_CALLS_LIMIT', 5);   // max calls per user per 24 hours

// ── PDO connection ────────────────────────────────────────────────────────────
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    error_log('DB connection failed: ' . $e->getMessage());
    die('<p style="color:red;font-family:sans-serif">Database error. Please try again later.</p>');
}
